// ==========================================================
// Kalkulator Nilai Akhir Mahasiswa
// Mini Project Pertemuan 10 - JavaScript dan DOM
// Alur: event (submit) -> handler -> logika hitung -> perubahan DOM
// ==========================================================

// ----- Konstanta (ditulis HURUF BESAR sesuai aturan penamaan) -----
const TOTAL_BOBOT_WAJIB = 100;
const BATAS_LULUS = 55;      // nilai minimal lulus (sesuaikan dengan aturan kampus/dosen)
const MAKS_RIWAYAT = 5;      // jumlah riwayat yang ditampilkan

// Skala nilai huruf (array of object), urut dari nilai tertinggi.
// Silakan sesuaikan dengan skala penilaian mata kuliah.
const SKALA_NILAI = [
  { min: 85, huruf: "A" },
  { min: 80, huruf: "A-" },
  { min: 75, huruf: "B+" },
  { min: 70, huruf: "B" },
  { min: 65, huruf: "B-" },
  { min: 60, huruf: "C+" },
  { min: 55, huruf: "C" },
  { min: 40, huruf: "D" },
  { min: 0,  huruf: "E" }
];

// Array untuk menyimpan riwayat perhitungan
const riwayat = [];

// ----- Memilih elemen DOM (getElementById & querySelector) -----
const formNilai     = document.getElementById("formNilai");
const btnReset      = document.getElementById("btnReset");
const pesan         = document.getElementById("pesan");
const totalBobotEl  = document.getElementById("totalBobot");
const hasilEl       = document.getElementById("hasil");
const nilaiAkhirEl  = document.getElementById("nilaiAkhir");
const nilaiHurufEl  = document.getElementById("nilaiHuruf");
const statusEl      = document.getElementById("status");
const rincianEl     = document.getElementById("rincian");
const daftarRiwayat = document.getElementById("daftarRiwayat");

// ==========================================================
// FUNGSI LOGIKA
// ==========================================================

// Mengambil data dari semua baris input menjadi array of object
function ambilData() {
  const data = [];
  const semuaBaris = document.querySelectorAll(".baris");

  for (let i = 0; i < semuaBaris.length; i++) {
    const baris = semuaBaris[i];
    const inputNilai = baris.querySelector(".input-nilai");
    const inputBobot = baris.querySelector(".input-bobot");

    data.push({
      nama: baris.querySelector(".nama").textContent,
      nilaiTeks: inputNilai.value.trim(),
      bobotTeks: inputBobot.value.trim(),
      nilai: Number(inputNilai.value),
      bobot: Number(inputBobot.value),
      inputNilai: inputNilai,
      inputBobot: inputBobot
    });
  }
  return data;
}

// Validasi input. Jika salah, lempar Error (ditangkap oleh try...catch)
function validasi(data) {
  let totalBobot = 0;

  data.forEach((item) => {
    if (item.nilaiTeks === "") {
      item.inputNilai.classList.add("error");
      throw new Error("Nilai " + item.nama + " belum diisi.");
    }
    if (item.nilai < 0 || item.nilai > 100) {
      item.inputNilai.classList.add("error");
      throw new Error("Nilai " + item.nama + " harus antara 0 sampai 100.");
    }
    if (item.bobotTeks === "" || item.bobot < 0) {
      item.inputBobot.classList.add("error");
      throw new Error("Bobot " + item.nama + " tidak valid.");
    }
    totalBobot += item.bobot;
  });

  // Pembulatan kecil untuk menghindari galat desimal (mis. 0.1 + 0.2)
  if (Math.round(totalBobot * 100) / 100 !== TOTAL_BOBOT_WAJIB) {
    throw new Error("Total bobot harus " + TOTAL_BOBOT_WAJIB + "%, saat ini " + totalBobot + "%.");
  }
}

// Rumus: nilai akhir = jumlah (nilai x bobot / 100)
function hitungNilaiAkhir(data) {
  let total = 0;
  for (const item of data) {
    total += item.nilai * item.bobot / 100;
  }
  return Math.round(total * 100) / 100; // 2 angka desimal
}

// Mencari nilai huruf berdasarkan skala
function tentukanHuruf(nilai) {
  for (const skala of SKALA_NILAI) {
    if (nilai >= skala.min) {
      return skala.huruf;
    }
  }
  return "E";
}

// Menghitung total bobot saat ini (untuk tampilan langsung)
function hitungTotalBobot() {
  let total = 0;
  document.querySelectorAll(".input-bobot").forEach((input) => {
    total += Number(input.value);
  });
  return Math.round(total * 100) / 100;
}

// ==========================================================
// FUNGSI PERUBAHAN DOM
// ==========================================================

function tampilkanPesan(teks, tipe) {
  pesan.textContent = teks;               // textContent: cara aman mengubah teks
  pesan.className = "pesan " + tipe;      // "pesan error" / "pesan sukses"
  pesan.hidden = false;
}

function sembunyikanPesan() {
  pesan.hidden = true;
}

function bersihkanTandaError() {
  document.querySelectorAll("input.error").forEach((el) => el.classList.remove("error"));
}

// Memperbarui tampilan total bobot (classList.add/remove)
function perbaruiTotalBobot() {
  const total = hitungTotalBobot();
  totalBobotEl.textContent = total + "%";
  totalBobotEl.classList.toggle("total-ok", total === TOTAL_BOBOT_WAJIB);
  totalBobotEl.classList.toggle("total-err", total !== TOTAL_BOBOT_WAJIB);
}

// Membuat tabel rincian dengan createElement + appendChild
function tampilkanRincian(data) {
  rincianEl.innerHTML = ""; // kosongkan isi lama

  data.forEach((item) => {
    const tr = document.createElement("tr");
    const kontribusi = Math.round(item.nilai * item.bobot) / 100;
    const kolom = [item.nama, item.nilai, item.bobot + "%", kontribusi];

    kolom.forEach((isi) => {
      const td = document.createElement("td");
      td.textContent = isi;
      tr.appendChild(td);
    });

    rincianEl.appendChild(tr);
  });
}

function tampilkanHasil(data, nilaiAkhir) {
  const huruf = tentukanHuruf(nilaiAkhir);
  const lulus = nilaiAkhir >= BATAS_LULUS;   // hasil boolean

  nilaiAkhirEl.textContent = nilaiAkhir;
  nilaiHurufEl.textContent = huruf;

  // Operator ternary
  statusEl.textContent = lulus ? "LULUS" : "TIDAK LULUS";
  statusEl.classList.toggle("lulus", lulus);
  statusEl.classList.toggle("tidak-lulus", !lulus);

  tampilkanRincian(data);
  hasilEl.hidden = false;

  tambahRiwayat(nilaiAkhir, huruf);
}

// Menyimpan ke array riwayat lalu menggambar ulang daftar
function tambahRiwayat(nilaiAkhir, huruf) {
  const waktu = new Date().toLocaleTimeString("id-ID");
  riwayat.unshift(waktu + " - Nilai akhir " + nilaiAkhir + " (" + huruf + ")");

  if (riwayat.length > MAKS_RIWAYAT) {
    riwayat.pop();
  }

  daftarRiwayat.innerHTML = "";
  riwayat.forEach((teks) => {
    const li = document.createElement("li");
    li.textContent = teks;
    daftarRiwayat.appendChild(li);
  });
}

// ==========================================================
// EVENT HANDLER
// ==========================================================

// Event 1: submit form -> hitung nilai akhir
formNilai.addEventListener("submit", (event) => {
  event.preventDefault();   // cegah halaman refresh
  bersihkanTandaError();

  try {
    const data = ambilData();
    validasi(data);
    const nilaiAkhir = hitungNilaiAkhir(data);
    tampilkanHasil(data, nilaiAkhir);
    tampilkanPesan("Perhitungan berhasil.", "sukses");
  } catch (error) {
    hasilEl.hidden = true;
    tampilkanPesan(error.message, "error");
  }
});

// Event 2: ubah bobot -> total bobot diperbarui langsung
document.querySelectorAll(".input-bobot").forEach((input) => {
  input.addEventListener("input", perbaruiTotalBobot);
});

// Event 3: tombol reset
btnReset.addEventListener("click", () => {
  formNilai.reset();          // kembalikan ke nilai awal HTML
  bersihkanTandaError();
  sembunyikanPesan();
  hasilEl.hidden = true;
  perbaruiTotalBobot();
});
